# Bluestein + Rader, and one fix that is not about them

Unpack from the directory that CONTAINS OddFFT/, not from inside it:

    cd ~/work
    tar xzf arb_patch.tar.gz
    cd OddFFT
    bash tests/run_tests.sh

It must end with `[TEST] ALL TESTS PASS`. If it does not, stop there and send
the output -- nothing below is worth running on a tree that fails its own
tests. run_tests.sh needs no device, no CANN and no extra include paths.

Then the new cells only, without re-running the 900 already collected:

    bash run_matrix.sh -c "$(printf '%s ' blu/bluestein_r{2,4}_{ps,psm}_xs rad/rader_r{2,4}_{ps,psm}_xs)"

288 cells = 8 variants x 4 N x 3 tile x 3 minT.
To stop a run: `touch ~/work/OddFFT/STOP` (checked at every cell boundary;
Ctrl-C does not reach a process sitting inside an NPU driver call).

## The 13 files

    host/host_twiddles.h    <-- the fix below; affects more than Bluestein
    host/impl_arblen.cpp    new: both constructions
    host/arb_common.h       new: number theory, the inner-FFT plan, write_bin
    host/registry.h         register_arblen()
    host/impl_odd.cpp       name pool -> std::deque (minor, see below)
    kernels/arb_cmul.cpp    new: a := a*b, complex, split layout
    kernels/arb_cscale.cpp  new: ar *= s; ai *= s*sign
    CMakeLists.txt          + impl_arblen.cpp (kernels are globbed already)
    scripts/gen_data.py     + --any, for N outside {2,3,5,7}
    run_matrix.sh           + N lists and dispatch for blu/* and rad/*
    tests/arb_selftest.cpp  new: both constructions vs a naive DFT
    tests/host_selftest.cpp + test 7, the regression for the fix
    tests/run_tests.sh      + arb_selftest

## The fix in host_twiddles.h

The host twiddle table is cached. The key was `(N, radices[0])`, which is not
a key at all: at N = 32 the plans [4,4,2] and [4,2,4] agree on both fields, and
so do [2,2,2,2,2] and [2,4,4]. The second plan to ask got the first plan's
table and returned a transform wrong by order 1 relative to the spectrum peak
-- not a loss of precision, a different answer, with no error and no warning.

It never fired in the benchmark because one process runs one variant with one
plan. It fired immediately once Bluestein's inner transform asked for several
plans of the same length. The key is now the whole radix list.

The regression for it is host_selftest test 7. Its FIRST version did not catch
the bug: it went through host_fft(), which computes its own cos/sin and never
touches the cache, so it passed with the broken key still in place. The
negative control is what exposed that. Test 7 now drives the cached path and
gives 21 failures on the broken key, 0 on the fixed one.

`impl_odd.cpp` is unrelated and minor: the variant-name pool was a
std::vector<std::string> whose c_str() was handed to the registry on push_back.
It was correct, because of a hand-computed reserve(2 * ODD_KERNEL_COUNT + 8),
but that guarantee held only as long as nobody added a kernel without
re-deriving the count. A std::deque never invalidates references, so it no
longer depends on arithmetic at the other end of the file.

## Why the new files do not include common/data_utils.h

That header includes "acl/acl.h" unconditionally, so anything touching it
cannot compile without the CANN include path -- and tests/run_tests.sh is
meant to run anywhere, with no device and no toolkit. The arbitrary-length
test links the shipped implementation rather than a copy of it, so one of
those two properties had to give. arb_common.h therefore carries an
eight-line write_bin() with the same semantics as WriteFile
(truncate-or-create, short write is a failure), and nothing new reaches for
the vendor header.

The first version of this patch instead passed `-I ../../stubs` in
run_tests.sh, a path that exists only on the machine the patch was built on.
It compiled there and nowhere else. The clean-tree check that caught it is
worth keeping as a habit: unpack into a directory with no siblings and run
the suite.

## Two defects the device build found, both in impl_arblen.cpp only

### 1. A brace-initialised struct with a default member initializer

`DevCtx` had `double cpu_us = 0.0;` and was initialised with `DevCtx ctx{...}`.
A default member initializer makes the type a non-aggregate under C++11, so
that stops compiling -- and the device build is C++11 here even though the
CMake target asks for -std=c++17: something in the toolkit's own flags puts an
earlier -std AFTER it, and the last one wins. The initializer is gone and the
field is set at the call site, which is correct under every standard. Checked
at c++11, c++14 and c++17 now, in both configurations, rather than only at the
one that was convenient.

### 2. Reading device memory while the kernel was still running

`aclrtMemcpy` is synchronous with respect to the HOST. It does not order
against work queued on an explicitly created stream. The first device version
copied the inner transform's data back right after launching the scale and
multiply kernels, with no `aclrtSynchronizeStream` in between, so it read
whatever was there. Every cell failed verification.

run_odd never meets this because it synchronises after every stage launch --
so the discipline was accidental rather than deliberate, and it did not get
carried over. Every launch is now followed by a synchronisation and every
host-visible copy preceded by one.

Neither defect can appear in the CPU-debug path, which is why 38/38 of the
self-test passed while nothing worked on the device.

## The device diagnostic: chk/inner_r2_xs and chk/inner_r4_xs

Added because "every cell fails" says nothing about where, and fixing one
hypothesis per round trip is expensive. These two variants compare the three
new device pieces against host arithmetic already proven against a naive DFT:

    1. arb_cmul       against a host complex multiply
    2. arb_cscale     against a host scale-and-conjugate
    3. the inner FFT  STAGE BY STAGE, stopping at the first divergence and
                      printing that stage's t, block, nBlk, wOffset, rowLen,
                      tile count and blockDim

Both sides start from identical data -- permuted, with the sub-floor prefix
already applied -- so a divergence is attributable to one stage. M is the same
next_pow2(2N-1) Bluestein would use, so the diagnosis is about the failing
configuration and not a convenient one.

They write no output file, so main() reports NO_OUTPUT (exit 2) and the matrix
records SKIP: they cannot contaminate a result. Run them directly:

    python3 scripts/gen_data.py -N 720 --any --input-dir ./input --output-dir ./output
    ./build/oddfft chk/inner_r4_xs 64 0 1 1
    ./build/oddfft chk/inner_r2_xs 64 0 1 1
    ./build/oddfft chk/inner_r4_xs 64 0 1 8

The last argument is MIN_T, which decides how many stages go to the device.

## What was measured locally

    arb_selftest           38/38 vs a naive O(N^2) DFT in double
    the real matrix sizes  11/11 vs NumPy, max_rel ~2e-7, up to M = 32768
    run_tests.sh           all four suites pass, in a tree with no stubs
    chk_kernels.sh         16 kernels clean
    host link              40 variants registered (32 + 4 frank + 8 new)

Not measured: anything on the device. The two new kernels have only been
syntax-checked.

## Timing convention, which differs from run_odd on purpose

One wall clock spans the whole transform here, and the PCIe transfers are
INSIDE it. run_odd leaves its two initial host-to-device copies outside both
timers. Not timing them here would reproduce the exact defect that motivated
rewriting these two constructions, so they are timed.

Consequence: `npu_us` is not comparable between the arbitrary-length rows and
the odd-radix rows. `total_us` is the honest column for both. For scale, the
copies run_odd leaves untimed are 2*N*4 bytes -- 806 KB at N = 100800, of order
80 us against a 6201 us total, about 1.3%.

## Why these N

    blu  720 3600 1331 10007
    rad  101 211 1009 10007

720 and 3600 are {2,3,5,7}-smooth, so mix/frank_* runs at the same N: that
pairing is the only way to price Bluestein's generality against a direct plan
that existed. 1331 = 11^3 and 10007 (prime) have no plan in the odd-radix path
at all. 10007 is in BOTH lists, so Bluestein against Rader is paired too.

The inner radix is an axis (_r2_ vs _r4_), not a decision taken here: the
power-of-two result that radix 4 wins 46 of 48 comparisons was collected only
at EVEN powers of two, where the plan is uniformly radix 4. A mixed
[2,4,4,...] plan, which is what an odd exponent forces, was never executed in
that matrix -- and it is where the cache bug above was hiding.
