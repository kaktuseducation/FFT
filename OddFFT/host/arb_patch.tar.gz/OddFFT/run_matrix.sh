#!/bin/bash
# OddFFT — the full comparison matrix.
#
#   variants (radix x butterfly x scheme x granularity x layout x cores)
#     x N x tile
#
# WHY THE N LIST IS PER RADIX
# In the power-of-two project every radix shared N = 2^(6k), so one N list
# served all of them and every cross-radix comparison was paired at identical
# N. No N above 1 is simultaneously a power of 3, of 5 and of 7, so that is
# impossible here. Each radix therefore gets its own list, chosen so the
# entries line up as closely as sizes of this shape can:
#
#     radix 3:   243    2187    19683
#     radix 5:   125    3125    15625
#     radix 7:   343    2401    16807
#              (small)  (mid)   (large)
#
# The mid row spans 1.43x and the large row 1.26x. Any conclusion drawn ACROSS
# radices has to go through the ns_per_pt column (total_us*1000 / (N*log2 N)),
# which output/matrix.csv carries for exactly this reason, and has to state
# that spread. Comparisons WITHIN a radix stay paired at identical N and are
# the strong ones.
#
# Usage:
#   bash run_matrix.sh                      # the default grid
#   bash run_matrix.sh -t "64 512"          # tiles only
#   bash run_matrix.sh -c "r3/sym_psm_xs"   # specific variants
#   bash run_matrix.sh -B "720 1331" -R "101 1009"   # arbitrary-length N lists
#   bash run_matrix.sh -c "$(./build/oddfft --list | tail -n +2 \
#        | awk -F, '/^blu|^rad/{print $1"/"$2}' | tr '\n' ' ')"   # those only
#   bash run_matrix.sh -w 1 -b 3            # fewer runs, quicker
#
# HOW TO STOP A RUN IN PROGRESS: create the file ./STOP in the project
# directory —
#     touch ~/work/OddFFT/STOP
# It is checked at every cell boundary. Ctrl-C is NOT reliable here: SIGINT
# does not reach a process sitting inside an NPU driver call, and bash then
# carries on to the next cell. That was learnt the hard way in the
# power-of-two project; the STOP file is the mechanism that was actually
# verified to work.

set -u
CURRENT_DIR=$(cd "$(dirname "${BASH_SOURCE:-$0}")" && pwd)
cd "$CURRENT_DIR"

RUN_MODE="npu"
SOC_VERSION="Ascend910B4"
N_LIST_R3="243 2187 19683"
N_LIST_R5="125 3125 15625"
N_LIST_R7="343 2401 16807"
N_LIST_R2="256 4096 32768"
N_LIST_R4="256 4096 65536"
# The combined transform takes any N factorisable over {2,3,5,7}. These are
# chosen to be genuinely mixed (no pure powers) and to bracket the sizes above,
# so frank can be compared against the single-radix variants at nearby N.
N_LIST_MIX="720 3600 30240 100800"
# Bluestein takes ANY N. Half this list is deliberately {2,3,5,7}-smooth so the
# same N also runs on mix/frank_*, which is the only way to price Bluestein's
# generality: at N = 720 and 3600 the two can be compared directly, and the
# ratio says what the detour through a length-M convolution costs when a direct
# plan existed. The other half is what Bluestein is actually for -- 1331 = 11^3
# and 10007 prime have no plan at all in the odd-radix path.
N_LIST_BLU="720 3600 1331 10007"
# Rader needs a PRIME N. 1009 and 10007 bracket the mid and large rows above;
# 101 and 211 are small enough that the host prefix still dominates, which is
# where the minT axis has something to say.
N_LIST_RAD="101 211 1009 10007"
TILE_LIST="8 64 352"   # 352 = ODDFFT_MAX_TILE; a larger request clamps to it
# The smallest operand distance t that still runs on the DEVICE.
#   1  every stage on the device. Possible because DataCopyPad was measured
#      correct below the 32-byte granule; whether it is FASTER is the question
#      this axis exists to answer, since a transfer costs about the same
#      whatever its length and a t=1 stage moves one float per run
#   8  the plain-DataCopy granule, where the floor used to sit
#   64 a comparison point: an earlier version passed the tile width here by
#      mistake, and the difference turned out to be most of the runtime
MINT_LIST="1 8 64"
WARMUP=2
BENCH_RUNS=5
VARIANTS=""
TIMEOUT_S=600

while getopts "r:v:3:5:7:2:4:m:B:R:t:M:w:b:c:T:" opt; do
    case "$opt" in
        r) RUN_MODE="$OPTARG" ;;
        v) SOC_VERSION="$OPTARG" ;;
        3) N_LIST_R3="$OPTARG" ;;
        5) N_LIST_R5="$OPTARG" ;;
        7) N_LIST_R7="$OPTARG" ;;
        2) N_LIST_R2="$OPTARG" ;;
        4) N_LIST_R4="$OPTARG" ;;
        m) N_LIST_MIX="$OPTARG" ;;
        B) N_LIST_BLU="$OPTARG" ;;
        R) N_LIST_RAD="$OPTARG" ;;
        t) TILE_LIST="$OPTARG" ;;
        M) MINT_LIST="$OPTARG" ;;
        w) WARMUP="$OPTARG" ;;
        b) BENCH_RUNS="$OPTARG" ;;
        c) VARIANTS="$OPTARG" ;;
        T) TIMEOUT_S="$OPTARG" ;;
        *) echo "[ERROR] unknown option: -$OPTARG"; exit 1 ;;
    esac
done

mkdir -p ./output ./logs
LOG="./logs/matrix_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee "$LOG") 2>&1
echo "[INFO] run_matrix.sh started, log=$LOG"
rm -f ./STOP

if [ -n "${ASCEND_INSTALL_PATH:-}" ]; then
    _ASCEND_INSTALL_PATH=$ASCEND_INSTALL_PATH
elif [ -n "${ASCEND_HOME_PATH:-}" ]; then
    _ASCEND_INSTALL_PATH=$ASCEND_HOME_PATH
elif [ -d "$HOME/Ascend/ascend-toolkit/latest" ]; then
    _ASCEND_INSTALL_PATH=$HOME/Ascend/ascend-toolkit/latest
else
    _ASCEND_INSTALL_PATH=/usr/local/Ascend/ascend-toolkit/latest
fi
echo "[INFO] ASCEND install path: ${_ASCEND_INSTALL_PATH}"
set +e
source "${_ASCEND_INSTALL_PATH}/bin/setenv.bash"
set -e
set +e

# One matrix run = one clean table, for the reason given in run.sh.
_ts="$(date +%Y%m%d_%H%M%S)"
for _csv in matrix results validation; do
    if [ -s "./output/${_csv}.csv" ]; then
        mv "./output/${_csv}.csv" "./output/${_csv}.csv.bak_${_ts}"
    fi
done

echo "[INFO] building once (RUN_MODE=${RUN_MODE})"
rm -rf build
cmake -B build \
    -DRUN_MODE=${RUN_MODE} \
    -DSOC_VERSION=${SOC_VERSION} \
    -DASCEND_CANN_PACKAGE_PATH=${_ASCEND_INSTALL_PATH} > ./logs/cmake_cfg.log 2>&1
cmake --build build -j > ./logs/cmake_build.log 2>&1
if [ ! -x ./build/oddfft ]; then
    echo "[ERROR] build failed — see logs/cmake_build.log"
    tail -40 ./logs/cmake_build.log
    exit 1
fi
export LD_LIBRARY_PATH="${CURRENT_DIR}/build/lib:${LD_LIBRARY_PATH:-}"
BIN=./build/oddfft

# The variant list comes from the binary, so the axes are not duplicated here.
LIST=$($BIN --list | tail -n +2)
if [ -z "$VARIANTS" ]; then
    VARIANTS=$(echo "$LIST" | awk -F, '{print $1"/"$2}' | tr '\n' ' ')
fi
echo "[INFO] variants: $VARIANTS"
echo "[INFO] tiles:    $TILE_LIST"
echo "[INFO] minT:     $MINT_LIST"
echo "[INFO] N  r2=$N_LIST_R2 | r3=$N_LIST_R3 | r4=$N_LIST_R4"
echo "[INFO] N  r5=$N_LIST_R5 | r7=$N_LIST_R7 | mix=$N_LIST_MIX"
echo "[INFO] N  blu=$N_LIST_BLU | rad=$N_LIST_RAD"

radix_of() {   # radix of a full variant name, read from --list
    echo "$LIST" | awk -F, -v v="$1" '{ if ($1"/"$2 == v) print $3 }'
}

# Dispatch on the IMPL first, then on the radix. blu/*, rad/* and mix/* all
# report radix 0 -- radix 0 is what tells main() that N need not be a power of
# anything -- so the radix alone cannot pick their N list, and Rader in
# particular would be handed composite sizes it must refuse.
n_list_for() {   # $1 = full variant name, $2 = its radix
    case "${1%%/*}" in
        blu) echo "$N_LIST_BLU"; return ;;
        rad) echo "$N_LIST_RAD"; return ;;
        mix) echo "$N_LIST_MIX"; return ;;
    esac
    case "$2" in
        0) echo "$N_LIST_MIX" ;;
        2) echo "$N_LIST_R2" ;;
        3) echo "$N_LIST_R3" ;;
        4) echo "$N_LIST_R4" ;;
        5) echo "$N_LIST_R5" ;;
        7) echo "$N_LIST_R7" ;;
        *) echo "" ;;
    esac
}

# Only the arbitrary-length families get gen_data's {2,3,5,7} check switched
# off. Everywhere else a mistyped N must still fail loudly rather than quietly
# produce data no variant can plan.
gen_flags_for() {
    case "${1%%/*}" in
        blu|rad) echo "--any" ;;
        *)       echo "" ;;
    esac
}

PASS=0; FAIL=0; SKIP=0; ERR=0; TMO=0; CELLS=0
STOPPED=0

for v in $VARIANTS; do
    r=$(radix_of "$v")
    if [ -z "$r" ]; then
        echo "[ERROR] variant $v is not in --list"
        ERR=$((ERR+1)); continue
    fi
    # radix 0 is the combined transform; everything else is a single radix.
    NS=$(n_list_for "$v" "$r")
    GEN_FLAGS=$(gen_flags_for "$v")
    for n in $NS; do
        # The data is regenerated per N, not per cell: it depends only on N.
        #
        # The old files are DELETED first and the exit code is CHECKED. Both
        # matter. If generation fails and the previous N's input_x.bin and
        # golden.bin are still lying there, the binary runs on the wrong N and
        # the verification PASSES -- input and golden are stale together, so
        # they agree with each other. That is a false PASS on a size that was
        # never tested, and it is invisible in the results table. It happened
        # once during development and is exactly the kind of thing that must
        # not reach a thesis.
        rm -f ./input/input_x.bin ./output/golden.bin
        if ! python3 scripts/gen_data.py -N "$n" $GEN_FLAGS --input-dir ./input \
                --output-dir ./output > /dev/null 2>&1; then
            echo "[ERROR] gen_data failed for N=$n -- skipping, NOT running on stale data"
            ERR=$((ERR+1))
            continue
        fi
        for t in $TILE_LIST; do
         for mt in $MINT_LIST; do
            if [ -f ./STOP ]; then
                echo ""
                echo "[STOP] ./STOP found — stopping at the cell boundary."
                STOPPED=1; break 4
            fi
            CELLS=$((CELLS+1))
            printf "[CELL ] %-18s radix=%s N=%-7s tile=%-4s minT=%-3s ... " \
                   "$v" "$r" "$n" "$t" "$mt"
            rc=0
            timeout "${TIMEOUT_S}" $BIN "$v" "$t" "$WARMUP" "$BENCH_RUNS" "$mt" \
                > "./logs/cell_${v//\//_}_N${n}_t${t}_m${mt}.log" 2>&1 || rc=$?
            case $rc in
                0)   echo "PASS"; PASS=$((PASS+1)) ;;
                2)   echo "SKIP (no output)"; SKIP=$((SKIP+1)) ;;
                3)   echo "FAIL (verification)"; FAIL=$((FAIL+1)) ;;
                124) echo "TIMEOUT (${TIMEOUT_S}s)"; TMO=$((TMO+1)) ;;
                *)   echo "ERROR rc=$rc"; ERR=$((ERR+1)) ;;
            esac
         done
        done
    done
done

echo ""
echo "[INFO] NumPy baselines for every N that was used"
for n in $N_LIST_R2 $N_LIST_R3 $N_LIST_R4 $N_LIST_R5 $N_LIST_R7 $N_LIST_MIX \
         $N_LIST_BLU $N_LIST_RAD; do
    rm -f ./input/input_x.bin ./output/golden.bin
    # --any throughout here: this loop only needs the data to exist so NumPy
    # has something to time, and a non-smooth N is legitimate for blu/rad.
    python3 scripts/gen_data.py -N "$n" --any --input-dir ./input --output-dir ./output > /dev/null 2>&1 || continue
    python3 scripts/bench_numpy.py --input ./input/input_x.bin --csv ./output/numpy_baseline.csv > /dev/null
done

echo ""
echo "================================================================"
echo "[DONE ] cells=$CELLS  PASS=$PASS  FAIL=$FAIL  SKIP=$SKIP  TIMEOUT=$TMO  ERROR=$ERR"
[ "$STOPPED" = "1" ] && echo "[DONE ] the run was stopped early by ./STOP"
echo "[DONE ] table: output/matrix.csv   log: $LOG"
echo "================================================================"
echo ""
python3 scripts/analyze_matrix.py
